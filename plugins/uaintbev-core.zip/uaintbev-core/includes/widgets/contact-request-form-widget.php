<?php

namespace UaintbevCore;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Contact_Request_Form_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'contact_request_form';
    }

    public function get_title() {
        return __( 'Contact Request Form', 'uaintbev-core' );
    }

    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return [ 'uaintbev-category' ]; // Add this widget to your custom category
    }

    protected function register_controls() {

        // Section for Content
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'uaintbev-core' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // Title Control
        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'uaintbev-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Request A Quote', 'uaintbev-core' ),
            ]
        );

        // Subtitle Control
        $this->add_control(
            'subtitle',
            [
                'label' => __( 'Subtitle', 'uaintbev-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __( 'Continually productize compelling quality for packed in business consulting.', 'uaintbev-core' ),
            ]
        );

        // Top Image Control
        $this->add_control(
            'top_image',
            [
                'label' => __( 'Top Shape Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // Bottom Image Control
        $this->add_control(
            'bottom_image',
            [
                'label' => __( 'Bottom Shape Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // Logo Control
        $this->add_control(
            'logo_image',
            [
                'label' => __( 'Logo Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        // WPForms Shortcode Control
        $this->add_control(
            'form_shortcode',
            [
                'label' => __( 'WPForms Shortcode', 'uaintbev-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '[contact-form-7 id="123" title="Contact Form"]',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        // Get all settings dynamically
        $title = $settings['title'];
        $subtitle = $settings['subtitle'];
        $top_image = $settings['top_image']['url'];
        $bottom_image = $settings['bottom_image']['url'];
        $logo_image = $settings['logo_image']['url'];
        $form_shortcode = $settings['form_shortcode'];
        ?>

<section class="request request--contactus">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div
                    class="section__header request__header request__header--headercontactpage d-flex justify-content-center">
                    <div class="col-md-8">
                        <span><?php echo esc_html( $title ); ?>
                            <img src="<?php echo esc_url( $logo_image ); ?>" alt="logo">
                        </span>
                        <h3><?php echo esc_html( $title ); ?></h3>
                        <p><?php echo esc_html( $subtitle ); ?></p>
                    </div>
                </div>
                <div class="section__wrapper request__form request__form--contactpage">
                    <?php echo do_shortcode( $form_shortcode ); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="topshape top-bottom d-lg-block d-none">
        <img src="<?php echo esc_url( $top_image ); ?>" alt="Top Shape">
    </div>
    <div class="bottomshape bottom-top d-xl-block d-none">
        <img src="<?php echo esc_url( $bottom_image ); ?>" alt="Bottom Shape">
    </div>
</section>
<?php
    }
}