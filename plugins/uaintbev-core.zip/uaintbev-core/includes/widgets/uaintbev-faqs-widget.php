<?php
namespace UaintbevCore;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Uaintbev_Core_Faqs_Widget extends Widget_Base {

    public function get_name() {
        return 'faqs_widget';
    }

    public function get_title() {
        return 'UA Int Bev FAQs Widget';
    }

    public function get_icon() {
        return 'eicon-help-o';
    }

    public function get_categories() {
        return ['uaintbev-category'];
    }

    protected function _register_controls() {

        // Section for Service Selection
        $this->start_controls_section(
            'faqs_settings',
            [
                'label' => 'UA Int Bev FAQs Settings',
            ]
        );

        $this->add_control(
            'faqs_style',
            [
                'label' => 'FAQs Style',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => 'Style 1',
                    'style_2' => 'Style 2',
                ],
                'default' => 'style_1',
            ]
        );

        $this->add_control(
            'faq_category',
            [
                'label' => 'FAQs Category',
                'type' => Controls_Manager::SELECT2,
                'options' => $this->get_faq_categories(),
                'multiple' => true,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'faq_count',
            [
                'label' => 'Number of FAQs',
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
            ]
        );

        $this->end_controls_section();

        // Section for Dynamic Fields
        $this->start_controls_section(
            'faq_content',
            [
                'label' => 'FAQs Content',
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => 'Title',
                'type' => Controls_Manager::TEXT,
                'default' => 'Asked Questions',
                'placeholder' => 'Enter your title here',
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => 'Subtitle',
                'type' => Controls_Manager::TEXT,
                'default' => 'Frequently Asked Questions.',
                'placeholder' => 'Enter your subtitle here',
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => 'Description',
                'type' => Controls_Manager::TEXTAREA,
                'default' => '',
                'placeholder' => 'Enter your description here',
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => 'Image',
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'logo_image',
            [
                'label' => 'Logo Image',
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => 'Button Text',
                'type' => Controls_Manager::TEXT,
                'default' => 'View All FAQs',
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => 'Button Link',
                'type' => Controls_Manager::URL,
                'placeholder' => 'https://your-link.com',
            ]
        );

        $this->add_control(
            'video_link',
            [
                'label' => 'Video Link',
                'type' => Controls_Manager::URL,
                'placeholder' => 'https://your-link.com',
            ]
        );

        $this->end_controls_section();
    }

    private function get_faq_categories() {
        $categories = get_terms([
            'taxonomy' => 'faq_category', // Replace with your taxonomy name
            'hide_empty' => false,
        ]);

        $options = [];
        foreach ($categories as $category) {
            $options[$category->term_id] = $category->name;
        }

        return $options;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Get the selected service style
        $faqs_style = $settings['faqs_style'];
    
        // Get the service category, title, subtitle, etc.
        $faq_category = $settings['faq_category'];

        $faq_count = $settings['faq_count'];
    
        // Fetch services based on the selected category
        $args = array(
            'post_type' => 'faq', // Replace with your custom post type for services
            'posts_per_page' => $faq_count, // Show all services
        );
        if (!empty($faq_category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'faq_category', // Replace with your custom taxonomy
                    'field'    => 'id',
                    'terms'    => $faq_category,
                    'operator' => 'IN',
                ),
            );
        }
    
        // Fetch the project
        $faqs = new \WP_Query($args);
    
        // Render the selected service style
        switch ($faqs_style) {
            case 'style_1':
                echo $this->get_faqs_style_1_html($settings, $faqs);
                break;
            case 'style_2':
                echo $this->get_faqs_style_2_html($settings, $faqs);
                break;
            
        }
    
    }
    
    private function get_faqs_style_1_html($settings, $faqs) {
        ob_start();
        ?>
<section class="question padding-block">
    <div class="container">
        <div class="section__header w-100">
            <div class="col-lg-7 col-xl-6">
                <span><?php echo esc_html($settings['title']); ?>
                    <?php if (!empty($settings['logo_image']['url'])) : ?>
                    <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                    <?php endif; ?>
                </span>
                <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                <p><?php echo esc_html($settings['description']); ?></p>
            </div>
        </div>
        <div class="row g-4 align-items-center">
            <div class="col-lg-7 col-xl-6">
                <div class="section__wrapper">
                    <div class="accordion" id="accordionExample">
                        <?php
                            if ($faqs->have_posts()) :
                                $i = 0;
                                while ($faqs->have_posts()) : $faqs->the_post();
                                    $faq_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                    $slug = basename(get_permalink());
                                    
                                    ?>
                        <div class="accordion-item accordion-item--itme2Serpage">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button <?php echo ($i != 0) ? ' collapsed' : '' ?>"
                                    type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo $slug;  ?>"
                                    aria-expanded="<?php echo ($i == 0) ? 'true': 'false'; ?>"
                                    aria-controls="<?php echo $slug; ?>"><?php the_title(); ?><span
                                        class="plus-icon"></span></button>
                            </h2>
                            <div id="<?php echo $slug; ?>"
                                class="accordion-collapse collapse <?php echo ($i == 0) ? ' show': ''; ?>"
                                aria-labelledby="<?php echo $slug;  ?>" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <p>
                                        <?php the_content(); ?>
                                    </p>
                                </div>
                            </div>
                        </div>



                        <?php
                        $i++; 
                                endwhile;
                            else :
                                echo '<p>No project found.</p>';
                            endif;
        
                            wp_reset_postdata();
                            ?>


                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-xl-6">
                <div class="question__rightimg imghover">
                    <img src="<?php echo esc_url($settings['image']['url']); ?>" alt="bakul">
                    <div class="plybtn plybtn--playbtn">
                        <a href="<?php echo esc_url($settings['video_link']['url']); ?>" class="popup">
                            <i class="fa-solid fa-play"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="leftshape top-bottom dnone">
        <img src="assets/img/home-2/question/topleft.png" alt="bakul">
    </div>
</section>
<?php
        return ob_get_clean();
    }
    
    private function get_faqs_style_2_html($settings, $faqs) {
        ob_start();
        ?>
<section class="question padding-block">
    <div class="container">
        <div class="section__header section__header--header2">
            <div class="col-lg-12 col-xl-12">
                <span><?php echo esc_html($settings['title']); ?>
                    <?php if (!empty($settings['logo_image']['url'])) : ?>
                    <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                    <?php endif; ?>
                </span>
                <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                <p><?php echo esc_html($settings['description']); ?></p>
            </div>
        </div>
        <div class="row g-4 align-items-center">

            <div class="section__wrapper">
                <div class="accordion" id="accordionExample">
                    <?php
                            if ($faqs->have_posts()) :
                                $i = 0;
                                while ($faqs->have_posts()) : $faqs->the_post();
                                    $faq_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                    $slug = basename(get_permalink());
                                    
                                    ?>
                    <div class="col-lg-6 col-md-6 col-xl-6"></div>
                    <div class="accordion-item accordion-item--itme2Serpage">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button <?php echo ($i != 0) ? ' collapsed' : '' ?>" type="button"
                                data-bs-toggle="collapse" data-bs-target="#<?php echo $slug;  ?>"
                                aria-expanded="<?php echo ($i == 0) ? 'true': 'false'; ?>"
                                aria-controls="<?php echo $slug; ?>"><?php the_title(); ?><span
                                    class="plus-icon"></span></button>
                        </h2>
                        <div id="<?php echo $slug; ?>"
                            class="accordion-collapse collapse <?php echo ($i == 0) ? ' show': ''; ?>"
                            aria-labelledby="<?php echo $slug;  ?>" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                <p>
                                    <?php the_content(); ?>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>

                <?php
                        $i++; 
                                endwhile;
                            else :
                                echo '<p>No project found.</p>';
                            endif;
        
                            wp_reset_postdata();
                            ?>


            </div>
        </div>


    </div>
    </div>
    <div class="leftshape top-bottom dnone">
        <img src="assets/img/home-2/question/topleft.png" alt="bakul">
    </div>
</section>
<?php
        return ob_get_clean();
    }

    
}     