<?php

namespace UaintbevCore;


use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Uaintbev_Core_Contact_Details_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'contact_details';
    }

    public function get_title() {
        return __( 'Contact Details', 'uaintbev-core' );
    }

    public function get_icon() {
        return 'eicon-tel-field';
    }

    public function get_categories() {
        return [ 'uaintbev-category' ]; // Assign widget to the custom category
    }

    protected function register_controls() {

        // Section for Content
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'uaintbev-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'contact_items',
            [
                'label' => __( 'Contact Items', 'uaintbev-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'icon',
                        'label' => __( 'Icon', 'uaintbev-core' ),
                        'type' => \Elementor\Controls_Manager::ICONS,
                        'default' => [
                            'value' => 'fas fa-location-dot',
                            'library' => 'solid',
                        ],
                    ],
                    [
                        'name' => 'title',
                        'label' => __( 'Title', 'uaintbev-core' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => __( 'Contact Title', 'uaintbev-core' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'details',
                        'label' => __( 'Details', 'uaintbev-core' ),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'default' => __( 'Contact details here', 'uaintbev-core' ),
                        'label_block' => true,
                    ],
                ],
                'default' => [
                    [
                        'title' => __( 'Our Restaurant Address', 'uaintbev-core' ),
                        'details' => 'Suite 02, Level 12, Sahera Tropical Center 218 New Elephant Road, Dhaka',
                        'icon' => [
                            'value' => 'fas fa-location-dot',
                            'library' => 'solid',
                        ],
                    ],
                    [
                        'title' => __( 'Our Phone Number', 'uaintbev-core' ),
                        'details' => '+8801678170593, 02-9611936',
                        'icon' => [
                            'value' => 'fas fa-phone',
                            'library' => 'solid',
                        ],
                    ],
                    [
                        'title' => __( 'Our Website Address', 'uaintbev-core' ),
                        'details' => 'info@gmail.com | http://info.com',
                        'icon' => [
                            'value' => 'fas fa-envelope',
                            'library' => 'solid',
                        ],
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        if ( ! empty( $settings['contact_items'] ) ) :
            ?>
<div class="contactus padding-block bg-white overflow-hidden">
    <div class="container">
        <div class="row g-4 justify-content-center">
            <?php foreach ( $settings['contact_items'] as $item ) : ?>
            <div class="col-md-6 col-lg-4">
                <div class="contactus__item">
                    <div class="contactus__inner">
                        <div class="thumb">
                            <?php if ( ! empty( $item['icon']['value'] ) ) : ?>
                            <i class="<?php echo esc_attr( $item['icon']['value'] ); ?>"></i>
                            <?php endif; ?>
                        </div>
                        <div class="text">
                            <h6><?php echo esc_html( $item['title'] ); ?></h6>
                            <ul>
                                <?php foreach ( explode( '|', $item['details'] ) as $detail ) : ?>
                                <li><?php echo esc_html( trim( $detail ) ); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php
        endif;
    }
}