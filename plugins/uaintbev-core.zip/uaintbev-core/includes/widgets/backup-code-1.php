<?php

namespace UaintbevCore;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Uaintbev_Core_Slider_Widget extends Widget_Base {

    public function get_name() {
        return 'uaintbev_welcome_content';
    }

    public function get_title() {
        return __( 'Uaintbev Welcome Content', 'uaintbev-core' );
    }

    public function get_icon() {
        return 'eicon-welcome';
    }

    public function get_categories() {
        return [ 'uaintbev-category' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_service_settings',
            [
                'label' => __( 'Uaintbev Welcome Settings', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'uaintbev_style',
            [
                'label'   => __( 'Uaintbev Welcome Style', 'uaintbev-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'uaintbev-core' ),
                    'style_2' => __( 'Style 2', 'uaintbev-core' ),
                    'style_3' => __( 'Style 2', 'uaintbev-core' ),
                ],
                'default' => 'style_1',
            ]
        );

        $this->add_image_controls([
            'mainimg' => __( 'Main Image', 'uaintbev-core' ),
            'gardenicon'     => __( 'Garden Icon Image', 'uaintbev-core' ),
            'awardicon'     => __( 'Award Icon Image', 'uaintbev-core' ),
            'shape'      => __( 'Shape Image', 'uaintbev-core' ),
            'topleftimg'      => __( 'Top Left Image', 'uaintbev-core' ),
            'bottomleftimg'        => __( 'Bottom Left Image', 'uaintbev-core' ),
        ]);

        $this->end_controls_section();

        // Section for Dynamic Fields
        $this->start_controls_section(
            'content_section',
            [
                'label' => 'Uaintbev Welcome Content',
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => 'Title',
                'type' => Controls_Manager::TEXT,
                'default' => 'Natureplant Services',
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => 'Subtitle',
                'type' => Controls_Manager::TEXT,
                'default' => 'Nature plant Best Services For Your Gardening.',
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => 'Description',
                'type' => Controls_Manager::WYSIWYG,
                'default' => 'Continually productize compelling quality for packed in business consulting.',
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => 'Button Text',
                'type' => Controls_Manager::TEXT,
                'default' => 'Read More',
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => 'Button Link',
                'type' => Controls_Manager::URL,
                'placeholder' => 'https://your-link.com',
            ]
        );

        $this->add_control(
            'garden_odometer',
            [
                'label' => 'Award Odometer',
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );
        $this->add_control(
            'garden_title',
            [
                'label' => 'Garden Title',
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );
        $this->add_control(
            'award_odometer',
            [
                'label' => 'Award Odometer',
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );
        $this->add_control(
            'award_title',
            [
                'label' => 'Award Title',
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
           
        );

        $this->add_control(
            'logo_image',
            [
                'label' => 'Logo Image',
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section();
    }

    private function add_image_controls( $images ) {
        foreach ( $images as $name => $label ) {
            $this->add_control(
                $name,
                [
                    'label'   => $label,
                    'type'    => Controls_Manager::MEDIA,
                    'default' => [ 'url' => Utils::get_placeholder_image_src() ],
                ]
            );
        }
    }

   

    protected function render() {
        $settings = $this->get_settings_for_display();

        $uaintbev_style = $settings['uaintbev_style'] ?? 'style_1';

        if ( $uaintbev_style === 'style_1' ) {
            echo $this->render_uaintbev_style_1( $settings );
        } else if( $uaintbev_style === 'style_2' ) {
            echo $this->render_uaintbev_style_2( $settings );
        } else {
            echo $this->render_uaintbev_style_3( $settings );
        }
    }

    private function transform_content($content) {
        // Use DOMDocument to manipulate the HTML
        $doc = new DOMDocument();
        // Suppress warnings for malformed HTML
        @$doc->loadHTML('<?xml encoding="utf-8" ?>' . $content);

// Find all `<ul>` elements
    $ulElements = $doc->getElementsByTagName('ul');

    foreach ($ulElements as $ul) {
    // Iterate through each `<li>` in the `<ul>`
            foreach ($ul->getElementsByTagName('li') as $li) {
            // Create a new <i> element with Font Awesome classes
                $icon = $doc->createElement('i');
                $icon->setAttribute('class', 'fa-sharp fa-solid fa-square-check');

                // Insert the <i> element before the text inside <li>
                        $li->insertBefore($icon, $li->firstChild);
                        }
                        }

                        // Save and return the transformed content
                        return $doc->saveHTML($doc->documentElement);
                        }




                        private function render_uaintbev_style_1( $settings) {
                        ob_start();
                        ?>
                        <section class="natureplant overflow-hidden">
                            <div class="container">
                                <div class="row justify-content-xxl-end justify-content-center">
                                    <div class="col-lg-10 col-xl-7 col-xxl-6">
                                        <div class="section__header natureplant__header">
                                            <div class="col-md-11 col-xl-12 col-xxl-8">
                                                <span> <?php echo esc_html( $settings['title'] ); ?><img
                                                        src="<?php echo esc_url( $settings['logo_image']['url'] ); ?>"
                                                        alt="bakul"></span>
                                                <h3><?php echo esc_html( $settings['subtitle'] ); ?></h3>
                                            </div>
                                        </div>
                                        <div class="section__wrapper natureplant__content">
                                            <?php echo $this->transform_content( $settings['description'] ); ?>
                                            <div class="natureplant__gardingmake">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo esc_url( $settings['garden_image']['url'] ); ?>"
                                                            alt="bakul">
                                                    </div>
                                                    <div class="text">
                                                        <h5 class="odometer"
                                                            data-odometer-final="<?php echo esc_html( $settings['garden_odometer'] ); ?>">
                                                            <?php echo esc_html( $settings['garden_odometer'] ); ?></h5>
                                                        <h6><?php echo esc_html( $settings['garden_title'] ); ?></h6>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo esc_url( $settings['award_image']['url'] ); ?>"
                                                            alt="bakul">
                                                    </div>
                                                    <div class="text">
                                                        <h5 class="odometer"
                                                            data-odometer-final="<?php echo esc_html( $settings['award_odometer'] ); ?>">
                                                            <?php echo esc_html( $settings['award_odometer'] ); ?></h5>
                                                        <h6><?php echo esc_html( $settings['award_title'] ); ?></h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>"
                                                class="custom-btn"><?php echo esc_html( $settings['button_text'] ); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="position leftimg imghover d-xxl-block d-none">
                                <img src="assets/img/home-1/welcome/leftimg.png" alt="bakul">
                            </div>
                            <div class="rightshape right-left d-lg-block d-none">
                                <img src="<?php echo esc_url($settings['main_image']['url']); ?>" alt="bakul">
                            </div>
                            <div class="position topshape d-xxl-block d-none">
                                <img src="<?php echo esc_url($settings['topleft']['url']); ?>" alt="bakul">
                            </div>
                            <div class="position middleshape d-xxl-block d-none">
                                <img src="assets/img/home-1/welcome/middleshape.png" alt="bakul">
                            </div>
                        </section>
                        <?php
        return ob_get_clean();
    }


    private function render_uaintbev_style_2( $settings ) {
        ob_start();
        ?>
                        <section class="natureplant natureplant--natureplantpage2 bg-white">
                            <div class="container">
                                <div class="row align-items-center g-4 justify-content-center">
                                    <div class="col-xl-5">
                                        <div class="section__header">
                                            <div class="col-md-12">
                                                <span><?php echo esc_html($settings['title']); ?><img
                                                        src="<?php echo esc_url($settings['logo_image']['url']); ?>"
                                                        alt="bakul"></span>
                                                <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                                            </div>
                                        </div>
                                        <div
                                            class="section__wrapper natureplant__content natureplant__content--contentpage2">
                                            <?php echo $this->transform_content($settings['description']); ?>
                                            <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                                                class="custom-btn"><?php echo esc_html($settings['button_text']); ?></a>
                                        </div>
                                    </div>
                                    <div class="col-xl-7">
                                        <div class="natureplant__innerimg imghover">
                                            <img src="<?php echo esc_url($settings['main_image']['url']); ?>"
                                                alt="bakul">
                                            <div class="counteritem">
                                                <div class="thumb">
                                                    <img src="<?php echo esc_url($settings['gardenicon']['url']); ?>"
                                                        alt="bakul">
                                                </div>
                                                <div class="text">
                                                    <h5 class="odometer"
                                                        data-odometer-final="<?php echo esc_html( $settings['garden_odometer'] ); ?>">
                                                        <?php echo esc_html( $settings['garden_odometer'] ); ?></h5>
                                                    <h6><?php echo esc_html($settings['garden_title']); ?></h6>
                                                </div>
                                            </div>
                                            <div class="counteritem counteritem2">
                                                <div class="thumb">
                                                    <img src="<?php echo esc_url($settings['awardicon']['url']); ?>"
                                                        alt="bakul">
                                                </div>
                                                <div class="text">
                                                    <h5 class="odometer"
                                                        data-odometer-final="<?php echo esc_html( $settings['award_odometer'] ); ?>">
                                                        <?php echo esc_html( $settings['award_odometer'] ); ?></h5>
                                                    <h6><?php echo esc_html($settings['award_title']); ?></h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="topleft left-right dnone">
                                <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
                            </div>
                            <div class="bottomright right-left d-lg-block d-none">
                                <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="bakul">
                            </div>
                        </section>
                        <?php
        return ob_get_clean();
    }

    private function render_uaintbev_style_3( $settings ) {
        ob_start();
        ?>
                        <section
                            class="natureplant natureplant--natureplantpage3 natureplant--natureplantpage2 bg-white">
                            <div class="container">
                                <div class="row g-4 align-items-xxl-center align-items-end justify-content-center">
                                    <div class="col-xl-5 col-xxl-7 text-center imghover">
                                        <img src="<?php echo esc_url($settings['main_image']['url']); ?>" alt="bakul">
                                    </div>
                                    <div class="col-lg-10 col-xl-7 col-xxl-5">
                                        <div class="section__header">
                                            <div class="col-xl-8">
                                                <span><?php echo esc_html($settings['title']); ?><img
                                                        src="<?php echo esc_url($settings['logo_image']['url']); ?>"
                                                        alt="bakul"></span>
                                                <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                                            </div>
                                        </div>
                                        <div class="section__wrapper natureplant__content">
                                            <?php echo $this->transform_content($settings['description']); ?>
                                            <div class="natureplant__gardingmake">
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo esc_url($settings['gardenicon']['url']); ?>"
                                                            alt="bakul">
                                                    </div>
                                                    <div class="text">
                                                        <h5 class="odometer"
                                                            data-odometer-final="<?php echo esc_html($settings['garden_odometer']); ?>">
                                                            <?php echo esc_html($settings['garden_odometer']); ?></h5>
                                                        <h6><?php echo esc_html($settings['garden_title']); ?></h6>
                                                    </div>
                                                </div>
                                                <div class="item">
                                                    <div class="thumb">
                                                        <img src="<?php echo esc_url($settings['awardicon']['url']); ?>"
                                                            alt="bakul">
                                                    </div>
                                                    <div class="text">
                                                        <h5 class="odometer"
                                                            data-odometer-final="<?php echo esc_html($settings['award_odometer']); ?>">
                                                            <?php echo esc_html($settings['award_odometer']); ?></h5>
                                                        <h6><?php echo esc_html($settings['award_title']); ?></h6>
                                                    </div>
                                                </div>
                                            </div>
                                            <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                                                class="custom-btn"><?php echo esc_html($settings['button_text']); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="samepositon bottomright d-md-block d-none">
                                <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
                            </div>
                            <div class="samepositon topright d-xl-block d-none">
                                <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
                            </div>
                            <div class="topleft top-bottom d-xl-block d-none">
                                <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="bakul">
                            </div>
                        </section>
                        <?php
        return ob_get_clean();
    }
}