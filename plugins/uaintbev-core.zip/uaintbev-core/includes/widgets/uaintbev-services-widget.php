<?php
namespace UaintbevCore;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Service_Widget extends Widget_Base {

    public function get_name() {
        return 'service_widget';
    }

    public function get_title() {
        return 'Service Widget';
    }

    public function get_icon() {
        return 'eicon-form-vertical';
    }

    public function get_categories() {
        return ['uaintbev-category'];
    }

    protected function _register_controls() {

        // Section for Service Selection
        $this->start_controls_section(
            'section_service_settings',
            [
                'label' => 'UA Int Bev Service Settings',
            ]
        );

        $this->add_control(
            'service_style',
            [
                'label' => 'Service Style',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => 'Style 1',
                    'style_2' => 'Style 2',
                ],
                'default' => 'style_1',
            ]
        );

        $this->add_control(
            'service_category',
            [
                'label' => 'Service Category',
                'type' => Controls_Manager::SELECT2,
                'options' => $this->get_service_categories(),
                'multiple' => true,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'service_count',
            [
                'label' => 'Number of Services',
                'type' => Controls_Manager::NUMBER,
                'default' => 10,
            ]
        );

        $this->end_controls_section();

        // Section for Dynamic Fields
        $this->start_controls_section(
            'section_service_dynamic_fields',
            [
                'label' => 'Dynamic Fields',
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => 'Title',
                'type' => Controls_Manager::TEXT,
                'default' => 'Natureplant Services',
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => 'Subtitle',
                'type' => Controls_Manager::TEXT,
                'default' => 'Nature plant Best Services For Your Gardening.',
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => 'Description',
                'type' => Controls_Manager::TEXTAREA,
                'default' => 'Continually productize compelling quality for packed in business consulting.',
            ]
        );

        $this->add_control(
            'top_image',
            [
                'label' => 'Top Image',
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'logo_image',
            [
                'label' => 'Logo Image',
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section();
    }

    private function get_service_categories() {
        $categories = get_terms([
            'taxonomy' => 'service_category', // Replace with your taxonomy name
            'hide_empty' => false,
        ]);

        $options = [];
        foreach ($categories as $category) {
            $options[$category->term_id] = $category->name;
        }

        return $options;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Get the selected service style
        $service_style = $settings['service_style'];
    
        // Get the service category, title, subtitle, etc.
        $service_category = $settings['service_category'];

        $service_count = $settings['service_count'];
    
        // Fetch services based on the selected category
        $args = array(
            'post_type' => 'service', // Replace with your custom post type for services
            'posts_per_page' => $service_count, // Show all services
        );
        if (!empty($service_category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'service_category', // Replace with your custom taxonomy
                    'field'    => 'id',
                    'terms'    => $service_category,
                    'operator' => 'IN',
                ),
            );
        }
    
        // Fetch the services
        $services = new \WP_Query($args);
    
        if ($service_style == 'style_1') {
            // Display Style 1 Grid
            echo $this->get_service_style_1_html($settings, $services);
        } else {
            // Display Style 2 Slider
            echo $this->get_service_style_2_html($settings, $services);
        }
    }
    
    private function get_service_style_1_html($settings, $services) {
        ob_start();
        ?>
<section class="service service--historypage padding-block overflow-hidden">
    <div class="container">
        <div class="section__header service__headerpage3">
            <div class="col-xl-6">
                <span><?php echo esc_html($settings['title']); ?>
                    <?php if (!empty($settings['logo_image']['url'])) : ?>
                    <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                    <?php endif; ?>
                </span>
                <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                <p><?php echo esc_html($settings['description']); ?></p>
            </div>
        </div>
        <div class="row g-4">
            <?php
                    if ($services->have_posts()) :
                        while ($services->have_posts()) : $services->the_post();
                            $service_icon = get_post_meta(get_the_ID(), '_icon', true);
                            $service_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                            $service_description = get_the_excerpt();
                            ?>
            <div class="col-md-6 col-lg-4">
                <div class="service__inner service__inner--innerservicepage">
                    <div class="thumb">
                        <img src="<?php echo esc_url($service_icon); ?>" alt="<?php the_title(); ?>">
                    </div>
                    <div class="text">
                        <h6><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
                        <p><?php echo esc_html($service_description); ?></p>
                        <a href="<?php the_permalink(); ?>">Read More <i class="fa-solid fa-chevrons-right"></i></a>
                    </div>
                </div>
            </div>
            <?php
                        endwhile;
                    else :
                        echo '<p>No services found.</p>';
                    endif;
    
                    wp_reset_postdata();
                    ?>
        </div>
    </div>
</section>
<?php
        return ob_get_clean();
    }
    
    private function get_service_style_2_html($settings, $services) {
        ob_start();
        ?>
<section class="service2 padding-block bg-white">
    <div class="container">
        <div class="section__header service2__header d-flex justify-content-center">
            <div class="col-md-8 col-lg-7 col-xl-6 col-xxl-5">
                <span><?php echo esc_html($settings['title']); ?>
                    <?php if (!empty($settings['logo_image']['url'])) : ?>
                    <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                    <?php endif; ?>
                </span>
                <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                <p><?php echo esc_html($settings['description']); ?></p>
            </div>
        </div>
        <div class="section__wrapper overflow-hidden service2__wrapper">
            <div class="service2__slider">
                <div class="swiper-wrapper">
                    <?php
                            if ($services->have_posts()) :
                                while ($services->have_posts()) : $services->the_post();
                                    $service_icon = get_post_meta(get_the_ID(), '_icon', true);
                                    $service_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                    ?>
                    <div class="swiper-slide">
                        <div class="service2__item service2__item--itemservicepage">
                            <div class="thumb imghover">
                                <img src="<?php echo esc_url($service_image); ?>" alt="<?php the_title(); ?>">
                                <div class="icon">
                                    <img src="<?php echo esc_url($service_icon); ?>" alt="<?php the_title(); ?>">
                                </div>
                            </div>
                            <div class="text bg-white">
                                <h6><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
                                <p><?php echo get_the_excerpt(); ?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                                endwhile;
                            else :
                                echo '<p>No services found.</p>';
                            endif;
        
                            wp_reset_postdata();
                            ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
        return ob_get_clean();
    }
}     