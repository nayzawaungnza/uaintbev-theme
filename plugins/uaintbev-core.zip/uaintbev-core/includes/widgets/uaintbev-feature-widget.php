<?php

namespace UaintbevCore;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Uaintbev_Core_Feature_Widget extends Widget_Base {

    public function get_name() {
        return 'uaintbev-feature';
    }

    public function get_title() {
        return __('Uaintbev Feature', 'uaintbev-core');
    }

    public function get_icon() {
        return 'eicon-handle';
    }

    public function get_categories() {
        return ['uaintbev-category'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Feature Content', 'uaintbev-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'feature_style',
            [
                'label' => 'Feature Style',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => 'Style 1',
                    'style_2' => 'Style 2',
                    'style_3' => 'Style 3',
                ],
                'default' => 'style_1',
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __('Title', 'uaintbev-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => __('Enter your title here', 'uaintbev-core'),
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => __('Subtitle', 'uaintbev-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '',
                'placeholder' => __('Enter your subtitle here', 'uaintbev-core'),
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => __('Description', 'uaintbev-core'),
                'type' => Controls_Manager::WYSIWYG,
                'default' => '',
                'placeholder' => __('Enter your description here', 'uaintbev-core'),
            ]
        );

        

        $this->add_control(
            'logo_image',
            [
                'label' => __('Logo Image', 'uaintbev-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        // Achievement Section
        $this->start_controls_section(
            'feature_item_section',
            [
                'label' => __('Feature Items', 'uaintbev-core'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'icon',
            [
                'label' => __('Icon', 'uaintbev-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label' => __('Title', 'uaintbev-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        

        $repeater->add_control(
            'description',
            [
                'label' => __('Description', 'uaintbev-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('', 'uaintbev-core'),
            ]
        );

        $this->add_control(
            'feature_item',
            [
                'label' => __('Feature Items', 'uaintbev-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $title = $settings['title'] ?? '';
        $subtitle = $settings['subtitle'] ?? '';
        $description = $settings['description'] ?? '';
        $logo_image = $settings['logo_image']['url'] ?? '';

        $feature_style = $settings['feature_style'] ?? 'style_1';

        switch ($feature_style) {
            case 'style_1':
                echo $this->render_feature_style_1($settings);
                break;
            case 'style_2':
                echo $this->render_feature_style_2($settings);
                break;
            case 'style_3':
                echo $this->render_feature_style_3($settings);
                break;
            default:
                echo $this->render_feature_style_1($settings);
        }
        
    }

    private function render_feature_style_1( $settings ) {
        ob_start();
        ?>
<section class="feature padding-block overflow-hidden bg-white">
    <div class="container">
        <div class="section__header section__header--header2">
            <?php if (!empty($settings['title'])) : ?>
            <span><?php echo esc_html($settings['title']); ?>
                <?php if (!empty($settings['logo_image']['url'])) : ?>
                <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                <?php endif; ?>
            </span>
            <?php endif; ?>
            <?php if (!empty($settings['subtitle'])) : ?>
            <h3><?php echo esc_html($settings['subtitle']); ?></h3>
            <?php endif; ?>
            <?php if (!empty($settings['description'])) : ?>
            <p><?php echo wp_kses_post($settings['description']); ?></p>

            <?php endif; ?>
        </div>
    </div>
    <div class="container">
        <div class="row g-4 justify-content-center">
            <?php if (!empty($settings['feature_item'])) : ?>
            <?php foreach ($settings['feature_item'] as $item) : ?>
            <div class="col-md-6 col-xl-3">
                <div class="feature__item">
                    <div class="feature__inner">
                        <div class="icon">
                            <img src="<?php echo esc_url( $item['icon']['url'] ); ?>" alt="bakul">
                        </div>
                        <div class="text">
                            <h6><?php echo esc_html( $item['title'] ); ?></h6>
                            <p><?php echo esc_html( $item['description'] );?> </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>


        </div>
    </div>
</section>
<?php
        return ob_get_clean();
    }

    private function render_feature_style_2( $settings ) {
        ob_start();
        ?>
<section class="feature padding-block overflow-hidden bg-white">
    <div class="container">
        <div class="section__header section__header--header2">
            <?php if (!empty($settings['title'])) : ?>
            <span><?php echo esc_html($settings['title']); ?>
                <?php if (!empty($settings['logo_image']['url'])) : ?>
                <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                <?php endif; ?>
            </span>
            <?php endif; ?>
            <?php if (!empty($settings['subtitle'])) : ?>
            <h3><?php echo esc_html($settings['subtitle']); ?></h3>
            <?php endif; ?>
            <?php if (!empty($settings['description'])) : ?>
            <p><?php echo wp_kses_post($settings['description']); ?></p>

            <?php endif; ?>
        </div>
    </div>
    <div class="container">
        <div class="row g-4 justify-content-center">

            <?php if (!empty($settings['feature_item'])) : ?>
            <?php foreach ($settings['feature_item'] as $item) : ?>
            <div class="col-md-6 col-xl-3">
                <div class="feature__item">
                    <div class="feature__inner feature__inner--innerpage3">
                        <div class="icon">
                            <img src="<?php echo esc_url( $item['icon']['url'] ); ?>" alt="bakul">
                        </div>
                        <div class="text">
                            <h6><?php echo esc_html( $item['title'] ); ?></h6>
                            <p><?php echo esc_html( $item['description'] );?> </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>


        </div>
    </div>
</section>
<?php

        return ob_get_clean();
    }

    private function render_feature_style_3( $settings ) {
        ob_start();
        ?>
<section class="feature padding-block overflow-hidden bg-white">
    <div class="container">
        <div class="section__header section__header--header2">
            <?php if (!empty($settings['title'])) : ?>
            <span><?php echo esc_html($settings['title']); ?>
                <?php if (!empty($settings['logo_image']['url'])) : ?>
                <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                <?php endif; ?>
            </span>
            <?php endif; ?>
            <?php if (!empty($settings['subtitle'])) : ?>
            <h3><?php echo esc_html($settings['subtitle']); ?></h3>
            <?php endif; ?>
            <?php if (!empty($settings['description'])) : ?>
            <p><?php echo wp_kses_post($settings['description']); ?></p>

            <?php endif; ?>
        </div>
    </div>
    <div class="container">
        <div class="row g-4 justify-content-center">

            <?php if (!empty($settings['feature_item'])) : ?>
            <?php foreach ($settings['feature_item'] as $item) : ?>
            <div class="col-md-4 col-xl-4 col-sm-6 col-xs-12">
                <div class="feature__item">
                    <div class="feature__inner feature__inner--innerpage3">
                        <div class="icon">
                            <img src="<?php echo esc_url( $item['icon']['url'] ); ?>" alt="bakul">
                        </div>
                        <div class="text">
                            <h6><?php echo esc_html( $item['title'] ); ?></h6>
                            <p><?php echo esc_html( $item['description'] );?> </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>


        </div>
    </div>
</section>
<?php

        return ob_get_clean();
    }

}