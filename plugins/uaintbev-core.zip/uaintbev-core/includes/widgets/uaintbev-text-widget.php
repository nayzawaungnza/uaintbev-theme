<?php

namespace UaintbevCore;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Uaintbev_Core_Text_Widget extends Widget_Base {

    public function get_name() {
        return 'uaintbev_text_content';
    }

    public function get_title() {
        return __( 'Uaintbev Text Editor', 'uaintbev-core' );
    }

    public function get_icon() {
        return 'eicon-editor-paragraph';
    }

    public function get_categories() {
        return [ 'uaintbev-category' ];
    }

    protected function register_controls() {

        // Section: Settings
        $this->start_controls_section(
            'section_service_settings',
            [
                'label' => __( 'Uaintbev Text Settings', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'uaintbev_style',
            [
                'label'   => __( 'Uaintbev Welcome Style', 'uaintbev-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'uaintbev-core' ),
                    'style_2' => __( 'Style 2', 'uaintbev-core' ),
                    'style_3' => __( 'Style 3', 'uaintbev-core' ),
                ],
                'default' => 'style_1',
            ]
        );

        $this->add_image_controls([
            'main_image'    => __( 'Main Image', 'uaintbev-core' ),
            'shape_image'   => __( 'Shape Image', 'uaintbev-core' ),
            'topleftimg'  => __( 'Top Left Image', 'uaintbev-core' ),
            'bottomleftimg' => __( 'Bottom Left Image', 'uaintbev-core' ),
        ]);

        $this->end_controls_section();

        // Section: Content
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Uaintbev Text Content', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'title',
            [
                'label'   => __( 'Title', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( '', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label'   => __( 'Subtitle', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( '', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'description',
            [
                'label'   => __( 'Description', 'uaintbev-core' ),
                'type'    => Controls_Manager::WYSIWYG,
                'default' => __( '', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label'   => __( 'Button Text', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Read More', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label'       => __( 'Button Link', 'uaintbev-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'logo_image',
            [
                'label' => __( 'Logo Image', 'uaintbev-core' ),
                'type'  => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section();
    }

    private function add_image_controls( $images ) {
        foreach ( $images as $name => $label ) {
            $this->add_control(
                $name,
                [
                    'label'   => $label,
                    'type'    => Controls_Manager::MEDIA,
                    //'default' => [ 'url' => Utils::get_placeholder_image_src() ],
                ]
            );
        }
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $uaintbev_style = $settings['uaintbev_style'] ?? 'style_1';

        switch ( $uaintbev_style ) {
            case 'style_2':
                echo $this->render_uaintbev_style_2( $settings );
                break;
            case 'style_3':
                echo $this->render_uaintbev_style_3( $settings );
            default:
                echo $this->render_uaintbev_style_1( $settings );
        }
    }
    

private function render_uaintbev_style_1( $settings ) {
                            ob_start();
                            ?>
<section class="natureplant overflow-hidden" style="padding-bottom:20px;">
    <div class="container">
        <div class="row justify-content-xxl-end justify-content-center">
            <div class="col-lg-12 col-xl-12 col-xxl-12">
                <div class="section__header natureplant__header">
                    <div class="col-md-12 col-xl-12 col-xxl-12">
                        <span><?php echo esc_html($settings['title']); ?>
                            <?php if (!empty($settings['logo_image']['url'])) : ?>
                            <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                            <?php endif; ?>
                        </span>
                        <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                        <p><?php echo esc_html($settings['description']); ?></p>
                    </div>
                </div>
                <?php if (!empty($settings['description'])) : ?>
                <div class="section__wrapper natureplant__content">
                    <?php echo wp_kses_post($settings['description']); ?>
                    <?php if (!empty($settings['button_text'])) : ?>
                    <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>"
                        class="custom-btn"><?php echo esc_html( $settings['button_text'] ); ?></a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="position leftimg imghover d-xxl-block d-none">
        <img src="assets/img/home-1/welcome/leftimg.png" alt="bakul">
    </div>
    <?php if ( ! empty( $settings['bottomleftimg']['url'] ) ) : ?>
    <div class="rightshape right-left d-lg-block d-none">
        <img src="<?php echo esc_url($settings['bottomleftimg']['url']); ?>" alt="bakul">
    </div>
    <?php endif; ?>
    <div class="position topshape d-xxl-block d-none">
        <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
    </div>
    <div class="position middleshape d-xxl-block d-none">
        <img src="assets/img/home-1/welcome/middleshape.png" alt="bakul">
    </div>
</section>
<?php
        return ob_get_clean();
    }

    private function render_uaintbev_style_2( $settings ) {
        ob_start();
        ?>
<section class="natureplant natureplant--natureplantpage2 bg-white" style="padding-bottom:20px;">
    <div class="container">
        <div class="row align-items-center g-4 justify-content-center">
            <div class="col-xl-7">
                <div class="section__header">
                    <div class="col-md-12">
                        <span><?php echo esc_html($settings['title']); ?><img
                                src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="bakul"></span>
                        <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                    </div>
                </div>
                <?php if (!empty($settings['description'])) : ?>
                <div class="section__wrapper natureplant__content natureplant__content--contentpage2">
                    <?php echo wp_kses_post($settings['description']); ?>
                    <?php if ( ! empty( $settings['button_text'] ) ) : ?>
                    <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                        class="custom-btn"><?php echo esc_html($settings['button_text']); ?></a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-xl-5">
                <div class="natureplant__innerimg imghover">
                    <img src="<?php echo esc_url($settings['main_image']['url']); ?>" alt="bakul">

                </div>
            </div>
        </div>
    </div>
    <?php if ( ! empty( $settings['topleftimg']['url'] ) ) : ?>
    <div class="topleftimg left-right dnone">
        <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
    </div>
    <?php endif; ?>
    <?php if ( ! empty( $settings['bottomleftimg']['url'] ) ) : ?>
    <div class="bottomright right-left d-lg-block d-none">
        <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="bakul">
    </div>
    <?php endif; ?>
</section>
<?php
        return ob_get_clean();
    }

    private function render_uaintbev_style_3( $settings ) {
        ob_start();
        ?>
<section class="natureplant natureplant--natureplantpage3 natureplant--natureplantpage2 bg-white"
    style="padding-bottom:20px;">
    <div class="container">
        <div class="row g-4 align-items-xxl-center align-items-end justify-content-center">
            <div class="col-xl-5 col-xxl-7 text-center imghover">
                <img src="<?php echo esc_url($settings['main_image']['url']); ?>" alt="bakul">
            </div>
            <div class="col-lg-10 col-xl-7 col-xxl-5">
                <div class="section__header">
                    <div class="col-xl-8">
                        <span><?php echo esc_html($settings['title']); ?><img
                                src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="bakul"></span>
                        <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                    </div>
                </div>
                <?php if (!empty($settings['description'])) : ?>
                <div class="section__wrapper natureplant__content">
                    <?php echo wp_kses_post($settings['description']); ?>

                    <?php if ( ! empty( $settings['button_text'] ) ) : ?>
                    <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                        class="custom-btn"><?php echo esc_html($settings['button_text']); ?></a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if ( ! empty( $settings['bottomleftimg']['url'] ) ) : ?>
    <div class="samepositon bottomright d-md-block d-none">
        <img src="<?php echo esc_url($settings['bottomleftimg']['url']); ?>" alt="bakul">
    </div>
    <?php endif; ?>
    <?php if ( ! empty( $settings['topleftimg']['url'] ) ) : ?>
    <div class="samepositon topright d-xl-block d-none">
        <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
    </div>
    <?php endif; ?>
    <?php if ( ! empty( $settings['shape_image']['url'] ) ) : ?>
    <div class="topleftimg top-bottom d-xl-block d-none">
        <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="bakul">
    </div>
    <?php endif; ?>
</section>
<?php
        return ob_get_clean();
    }
}