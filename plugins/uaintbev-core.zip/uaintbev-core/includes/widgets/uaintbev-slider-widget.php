<?php

namespace UaintbevCore;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Uaintbev_Core_Slider_Widget extends Widget_Base {

    public function get_name() {
        return 'uaintbev_slider';
    }

    public function get_title() {
        return __( 'Uaintbev Slider', 'uaintbev-core' );
    }

    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_categories() {
        return [ 'uaintbev-category' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_service_settings',
            [
                'label' => __( 'Slider Settings', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'slider_style',
            [
                'label'   => __( 'Slider Style', 'uaintbev-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'uaintbev-core' ),
                    'style_2' => __( 'Style 2', 'uaintbev-core' ),
                ],
                'default' => 'style_1',
            ]
        );

        $this->add_image_controls([
            'contentrightimg' => __( 'Content Right Image', 'uaintbev-core' ),
            'topleftimg'      => __( 'Top Left Image', 'uaintbev-core' ),
            'topright'        => __( 'Top Right Image', 'uaintbev-core' ),
            'bottomleft'      => __( 'Bottom Left Image', 'uaintbev-core' ),
            'bottommiddle'    => __( 'Bottom Middle Image', 'uaintbev-core' ),
            'bottomright'     => __( 'Bottom Right Image', 'uaintbev-core' ),
            'middleshape'     => __( 'Middle Shape Image', 'uaintbev-core' ),
        ]);

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Slider Content', 'uaintbev-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'slider_items',
            [
                'label'       => __( 'Slider Items', 'uaintbev-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $this->get_repeater_fields(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();
    }

    private function add_image_controls( $images ) {
        foreach ( $images as $name => $label ) {
            $this->add_control(
                $name,
                [
                    'label'   => $label,
                    'type'    => Controls_Manager::MEDIA,
                    'default' => [ 'url' => Utils::get_placeholder_image_src() ],
                ]
            );
        }
    }

    private function get_repeater_fields() {
        return [
            [
                'name'    => 'slide_image',
                'label'   => __( 'Image', 'uaintbev-core' ),
                'type'    => Controls_Manager::MEDIA,
                'default' => [ 'url' => Utils::get_placeholder_image_src() ],
            ],
            [
                'name'        => 'title',
                'label'       => __( 'Title', 'uaintbev-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Slide Title', 'uaintbev-core' ),
                'label_block' => true,
            ],
            [
                'name'        => 'details',
                'label'       => __( 'Details', 'uaintbev-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'default'     => __( 'Slide details here', 'uaintbev-core' ),
                'label_block' => true,
            ],
            [
                'name'        => 'button_text',
                'label'       => __( 'Button Text', 'uaintbev-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Read More', 'uaintbev-core' ),
                'label_block' => true,
            ],
            [
                'name'        => 'button_link',
                'label'       => __( 'Button Link', 'uaintbev-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'uaintbev-core' ),
                'label_block' => true,
            ],
        ];
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $slider_style = $settings['slider_style'] ?? 'style_1';
        $slider_items = $settings['slider_items'] ?? [];

        if ( $slider_style === 'style_1' ) {
            echo $this->render_slider_style_1( $settings, $slider_items );
        } else {
            echo $this->render_slider_style_2( $settings, $slider_items );
        }
    }

    private function render_slider_style_1( $settings, $slider_items ) {
        ob_start();
        ?>
<div class="banner">
    <div class="hostbanner overflow-hidden">
        <div class="swiper-wrapper">
            <?php foreach ( $slider_items as $item ) : ?>
            <div class="swiper-slide">
                <div class="container">
                    <div class="banner__content col-md-7 col-xl-6">
                        <h3><?php echo esc_html( $item['title'] ?? '' ); ?></h3>
                        <p><?php echo esc_html( $item['details'] ?? '' ); ?></p>
                        <?php if ( ! empty( $item['button_text'] ) && ! empty( $item['button_link']['url'] ) ) : ?>
                        <div class="bannerbtn">
                            <a href="<?php echo esc_url( $item['button_link']['url'] ); ?>" class="custom-btn">
                                <?php echo esc_html( $item['button_text'] ); ?>
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php $this->render_images( $settings ); ?>
</div>
<?php
        return ob_get_clean();
    }

    private function render_images( $settings ) {
        $images = [
            'contentrightimg' => 'Content Right Image',
            'topleftimg'      => 'Top Left Image',
            'topright'        => 'Top Right Image',
            'bottomleft'      => 'Bottom Left Image',
            'bottommiddle'    => 'Bottom Middle Image',
            'bottomright'     => 'Bottom Right Image',
            'middleshape'     => 'Middle Shape Image',
        ];

        foreach ( $images as $name => $label ) {
            if ( ! empty( $settings[ $name ]['url'] ) ) {
                printf(
                    '<div class="position_bshape %1$s"><img src="%2$s" alt="%3$s"></div>',
                    esc_attr( $name ),
                    esc_url( $settings[ $name ]['url'] ),
                    esc_attr( $label )
                );
            }
        }
    }

    private function render_slider_style_2( $settings, $slider_items ) {
        ob_start();
        ?>
<div class="banner banner--bannertwo">
    <div class="hostbanner overflow-hidden">
        <div class="swiper-wrapper">
            <?php foreach ( $slider_items as $item ) : ?>
            <div class="swiper-slide"
                style="background: url('<?php echo esc_url( $item['slide_image']['url'] ?? '' ); ?>') no-repeat center center; background-size: cover;">
                <div class="container">
                    <div
                        class="banner__content banner__content--contentpage2 row justify-content-center overflow-hidden">
                        <div class="col-lg-8">
                            <h3><?php echo esc_html( $item['title'] ?? '' ); ?></h3>
                            <p><?php echo esc_html( $item['details'] ?? '' ); ?></p>
                            <?php if ( ! empty( $item['button_text'] ) && ! empty( $item['button_link']['url'] ) ) : ?>
                            <div class="bannerbtn">
                                <a href="<?php echo esc_url( $item['button_link']['url'] ); ?>" class="custom-btn">
                                    <?php echo esc_html( $item['button_text'] ); ?>
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php
        return ob_get_clean();
    }
}