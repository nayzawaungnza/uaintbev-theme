<?php
namespace UaintbevCore;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Uaintbev_Core_Project_Widget extends Widget_Base {

    public function get_name() {
        return 'project_widget';
    }

    public function get_title() {
        return 'Project Widget';
    }

    public function get_icon() {
        return 'eicon-apps';
    }

    public function get_categories() {
        return ['uaintbev-category'];
    }

    protected function _register_controls() {

        // Section for Service Selection
        $this->start_controls_section(
            'project_settings',
            [
                'label' => 'UA Int Bev Project Settings',
            ]
        );

        $this->add_control(
            'project_style',
            [
                'label' => 'Project Style',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => 'Style 1',
                    'style_2' => 'Style 2',
                    'style_3' => 'Style 3',
                ],
                'default' => 'style_1',
            ]
        );

        $this->add_control(
            'project_category',
            [
                'label' => 'Project Category',
                'type' => Controls_Manager::SELECT2,
                'options' => $this->get_project_categories(),
                'multiple' => true,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'project_count',
            [
                'label' => 'Number of Project',
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
            ]
        );

        $this->end_controls_section();

        // Section for Dynamic Fields
        $this->start_controls_section(
            'project_content',
            [
                'label' => 'Project Content',
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => 'Title',
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => 'Enter your title here',
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => 'Subtitle',
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => 'Enter your subtitle here',
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => 'Description',
                'type' => Controls_Manager::TEXTAREA,
                'default' => '',
                'placeholder' => 'Enter your description here',
            ]
        );

        $this->add_control(
            'shape_image',
            [
                'label' => 'Shape Image',
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'logo_image',
            [
                'label' => 'Logo Image',
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => 'Button Text',
                'type' => Controls_Manager::TEXT,
                'default' => 'View All Project',
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => 'Button Link',
                'type' => Controls_Manager::URL,
                'placeholder' => 'https://your-link.com',
            ]
        );

        $this->end_controls_section();
    }

    private function get_project_categories() {
        $categories = get_terms([
            'taxonomy' => 'project_category', // Replace with your taxonomy name
            'hide_empty' => false,
        ]);

        $options = [];
        foreach ($categories as $category) {
            $options[$category->term_id] = $category->name;
        }

        return $options;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Get the selected service style
        $project_style = $settings['project_style'];
    
        // Get the service category, title, subtitle, etc.
        $service_category = $settings['project_category'];

        $project_count = $settings['project_count'];
    
        // Fetch services based on the selected category
        $args = array(
            'post_type' => 'project', // Replace with your custom post type for services
            'posts_per_page' => $project_count, // Show all services
        );
        if (!empty($service_category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'project_category', // Replace with your custom taxonomy
                    'field'    => 'id',
                    'terms'    => $service_category,
                    'operator' => 'IN',
                ),
            );
        }
    
        // Fetch the project
        $projects = new \WP_Query($args);
    
        // Render the selected service style
        switch ($project_style) {
            case 'style_1':
                echo $this->get_project_style_1_html($settings, $projects);
                break;
            case 'style_2':
                echo $this->get_project_style_2_html($settings, $projects);
                break;
            case 'style_3':
                echo $this->get_project_style_3_html($settings, $projects);
                break;
        }
    
    }
    
    private function get_project_style_1_html($settings, $projects) {
        ob_start();
        ?>
<section class="project overflow-hidden padding-block">
    <div class="container">
        <div class="section__header section__header--header2">
            <span><?php echo esc_html($settings['title']); ?>
                <?php if (!empty($settings['logo_image']['url'])) : ?>
                <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                <?php endif; ?>
            </span>
            <h3><?php echo esc_html($settings['subtitle']); ?></h3>
            <p><?php echo esc_html($settings['description']); ?></p>
        </div>
    </div>
    <div class="section__wrapper project__wrapper">
        <div class="project__slider overflow-hidden">
            <div class="swiper-wrapper">

                <?php
                            if ($projects->have_posts()) :
                                while ($projects->have_posts()) : $projects->the_post();
                                    $project_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                    $categories = get_the_category();
                                    ?>
                <div class="swiper-slide">
                    <div class="project__inner">
                        <div class="project__item">
                            <div class="thum">
                                <img src="<?php echo esc_url($project_image); ?>" alt="<?php the_title(); ?>">
                            </div>
                            <div class="content go-up">
                                <div class="content-inner">
                                    <?php
                                    if (!empty($categories)) {
                                        $category_names = [];
                                        foreach ($categories as $category) {
                                            $category_names[] = esc_html($category->name); // Collect category names
                                        }
                                
                                        // Output categories as a comma-separated list
                                        echo '<p>' . implode(', ', $category_names) . '</p>';
                                    }
                                    ?>
                                    <h6><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <?php
                                endwhile;
                            else :
                                echo '<p>No project found.</p>';
                            endif;
        
                            wp_reset_postdata();
                            ?>



            </div>
        </div>
        <?php if (!empty($settings['button_text'])) : ?>

        <div class="project__btn">
            <a href="<?php echo esc_url($settings['button_link']['url']); ?>" class="custom-btn">
                <?php echo esc_html($settings['button_text']); ?>
            </a>
        </div>
        <?php endif; ?>
    </div>
</section>
<?php
        return ob_get_clean();
    }
    
    private function get_project_style_2_html($settings, $projects) {
        ob_start();
        ?>
<div class="projectfilter padding-block  overflow-hidden bg-white">
    <div class="container">
        <div class="section__header section__header--header2 d-flex justify-content-center">
            <div class="col-xl-8">
                <span><?php echo esc_html($settings['title']); ?>
                    <?php if (!empty($settings['logo_image']['url'])) : ?>
                    <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                    <?php endif; ?>
                </span>
                <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                <p><?php echo esc_html($settings['description']); ?></p>
            </div>
        </div>
        <div class="section__wrapper">
            <div class="projectfilter__header">
                <ul>
                    <li class="item active" data-sort-by="*">all</li>
                    <?php
                    $terms = get_the_terms(get_the_ID(), 'project_category');
                    if ($terms && !is_wp_error($terms)) {
                        foreach ($terms as $term) {
                            echo '<li class="item" data-sort-by=".' . $term->slug . '">' . $term->name . '</li>';
                        }
                    }
                     ?>


                </ul>
            </div>
            <div class="projectfilter__wrapper">
                <div class="row g-4 projectfilter__filter">
                    <?php
                            if ($projects->have_posts()) :
                                while ($projects->have_posts()) : $projects->the_post();
                                    $project_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                    $categories = get_the_category();
                                    ?>

                    <div class="col-sm-6 col-lg-4 item1">
                        <div class="projectfilter__item">
                            <a href="<?php the_permalink(); ?>" class="go-top">
                                <img src="<?php echo esc_url($project_image); ?>" alt="<?php the_title(); ?>">
                            </a>
                            <div class="inneritem go-up">
                                <div class="upitem search">
                                    <a href="<?php echo esc_url($project_image); ?>"
                                        data-rel="lightcase:myCollections"><i
                                            class="fa-sharp fa-regular fa-eye"></i></a>
                                </div>
                                <div class="upitem link">
                                    <a href="<?php the_permalink(); ?>"><i class="fa-solid fa-link"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>


                    <?php
                                endwhile;
                            else :
                                echo '<p>No project found.</p>';
                            endif;
        
                            wp_reset_postdata();
                ?>


                </div>
            </div>
        </div>
        <?php if (!empty($settings['button_text'])) : ?>
        <div class="projectfilter__btn">
            <a href="<?php echo esc_url($settings['button_link']['url']); ?>" class="custom-btn">
                <?php echo esc_html($settings['button_text']); ?>
            </a>
        </div>
        <?php endif; ?>

    </div>
    <div class="leftshape top-bottom">
        <img src="assets/img/home-2/filterproject/topshape.png" alt="bakul">
    </div>
    <?php if (!empty($settings['button_text'])) : ?>
    <div class="rightbottom right-left d-lg-block d-none">
        <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="bakul">
    </div>
    <?php endif; ?>
</div>
<?php
        return ob_get_clean();
    }

    private function get_project_style_3_html($settings, $projects) {
        ob_start();
        ?>
<section class="project project--projectpage3 overflow-hidden padding-block">
    <div class="container">
        <div class="section__header section__header--header2">
            <span><?php echo esc_html($settings['title']); ?>
                <?php if (!empty($settings['logo_image']['url'])) : ?>
                <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                <?php endif; ?>
            </span>
            <h3><?php echo esc_html($settings['subtitle']); ?></h3>
            <p><?php echo esc_html($settings['description']); ?></p>
        </div>
    </div>
    <div class="section__wrapper project__wrapper">
        <div class="project__slider2 overflow-hidden">
            <div class="swiper-wrapper">

                <?php
                            if ($projects->have_posts()) :
                                while ($projects->have_posts()) : $projects->the_post();
                                    $project_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                    $categories = get_the_category();
                                    ?>
                <div class="swiper-slide">
                    <div class="project__inner">
                        <div class="project__item">
                            <div class="thum">
                                <img src="<?php echo esc_url($project_image); ?>" alt="<?php the_title(); ?>">
                            </div>
                            <div class="content go-up">
                                <div class="content-inner">
                                    <?php
                                    if (!empty($categories)) {
                                        $category_names = [];
                                        foreach ($categories as $category) {
                                            $category_names[] = esc_html($category->name); // Collect category names
                                        }
                                
                                        // Output categories as a comma-separated list
                                        echo '<p>' . implode(', ', $category_names) . '</p>';
                                    }
                                    ?>
                                    <h6><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <?php
                                endwhile;
                            else :
                                echo '<p>No project found.</p>';
                            endif;
        
                            wp_reset_postdata();
                            ?>
            </div>
            <!-- <div class="project__pre swiper-button-prev"></div>
                <div class="project__next swiper-button-next"></div> -->
        </div>

        <?php if (!empty($settings['button_text'])) : ?>
        <div class="project__btn">
            <a href="<?php echo esc_url($settings['button_link']['url']); ?>" class="custom-btn">
                <?php echo esc_html($settings['button_text']); ?>
            </a>
        </div>
        <?php endif; ?>

    </div>
</section>
<?php
        return ob_get_clean();
    }
}     