<?php

namespace UaintbevCore;


use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Uaintbev_Core_Slider_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'uaintbev_slider';
    }

    public function get_title() {
        return __( 'Uaintbev Slider', 'uaintbev-core' );
    }

    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_categories() {
        return [ 'uaintbev-category' ]; // Assign widget to the custom category
    }

    protected function register_controls() {

        // Section for Service Selection
        $this->start_controls_section(
            'section_service_settings',
            [
                'label' => 'UA Int Bev Slider Settings',
            ]
        );

        $this->add_control(
            'slider_style',
            [
                'label' => 'Service Style',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'style_1' => 'Style 1',
                    'style_2' => 'Style 2',
                ],
                'default' => 'style_1',
            ]
        );

        $this->add_control(
            'contentrightimg',
            [
                'label' => __( 'Content Right Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                ]
            ]
            
        );
        $this->add_control(
            'topleftimg',
            [
                'label' => __( 'Top Left Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                ]
            ]
            
        );

        $this->add_control(
            'topright',
            [
                'label' => __( 'Top Right Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                ]
            ]
            
        );
        $this->add_control(
            'bottomleft',
            [
                'label' => __( 'Bottom Left Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                ]
            ]
            
        );

        $this->add_control(
            'bottommiddle',
            [
                'label' => __( 'Bottom Middle Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                ]
            ]
            
        );

        $this->add_control(
            'bottomright',
            [
                'label' => __( 'Bottom Right Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                ]
            ]
            
        );

        $this->add_control(
            'middleshape',
            [
                'label' => __( 'Middle Shape Image', 'uaintbev-core' ),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                ]
            ]
            
        );

        $this->end_controls_section();

        // Section for Content
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'UA Int Bev Slider', 'uaintbev-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'slider_items',
            [
                'label' => __( 'Slider Items', 'uaintbev-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'slide_image',
                        'label' => __( 'Image', 'uaintbev-core' ),
                        'type' => Controls_Manager::MEDIA,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'name' => 'title',
                        'label' => __( 'Title', 'uaintbev-core' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => __( 'Slide Title', 'uaintbev-core' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'details',
                        'label' => __( 'Details', 'uaintbev-core' ),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'default' => __( 'Slide details here', 'uaintbev-core' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'button_text',
                        'label' => __( 'Button Text', 'uaintbev-core' ),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => __( 'Read More', 'uaintbev-core' ),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'button_link',
                        'label' => __( 'Button Link', 'uaintbev-core' ),
                        'type' => \Elementor\Controls_Manager::URL,
                        'placeholder' => __( 'https://your-link.com', 'uaintbev-core' ),
                        'label_block' => true,
                    ],
                ],
                
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $slider_style = $settings['slider_style'];

        $slider_items = $settings['slider_items'];

       if($slider_style == 'style_1') {
            $this->get_slider_style_1_html($settings,$slider_items);
       } else {
            $this->get_slider_style_2_html($settings,$slider_items);
       }
        


        
    }

    private function get_slider_style_1_html($settings, $slider_items, $slider_shape_image) {
        ob_start();
?>
<div class="banner">
    <div class="hostbanner overflow-hidden">
        <div class="swiper-wrapper">
            <?php foreach ( $slider_items as $item ) : ?>
            <div class="swiper-slide">
                <div class="container">
                    <div class="banner__content col-md-7 col-xl-6">
                        <h3><?php echo esc_html( $item['title'] ); ?></h3>
                        <p><?php echo esc_html( $item['details'] ); ?></p>
                        <div class="bannerbtn">
                            <a href="<?php echo esc_url( $item['button_link']['url'] ); ?>" class="custom-btn">
                                <?php echo esc_html( $item['button_text'] ); ?>
                            </a>

                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>


        </div>
    </div>

    <div class="position_bshape contentrightimg imghover d-md-block d-none">
        <img src="<?php echo esc_url($settings['contentrightimg']['url']) ?>" alt="bakul">
    </div>
    <div class="position_bshape topleftimg dnone">
        <img src="<?php echo esc_url($settings['topleftimg']['url']) ?>" alt="bakul">
    </div>
    <div class="position_bshape topright">
        <img src="<?php echo esc_url($settings['topright']['url']) ?>" alt="bakul">
    </div>
    <div class="position_bshape bottomleft d-xl-block d-none">
        <img src="<?php echo esc_url($settings['bottomleft']['url']) ?>" alt="bakul">
    </div>
    <div class="position_bshape bottommiddle d-lg-block d-none">
        <img src="<?php echo esc_url($settings['bottommiddle']['url']) ?>" alt="bakul">
    </div>
    <div class="position_bshape bottomright d-sm-block d-none">
        <img src="<?php echo esc_url($settings['bottomright']['url']) ?>" alt="bakul">
    </div>
    <div class="position_bshape middleshape d-lg-block d-none">
        <img src="<?php echo esc_url($settings['middleshape']['url']) ?>" alt="bakul">
    </div>
</div>
<?php
        return ob_get_clean();
    }
    private function get_slider_style_2_html($settings, $slider_items) {
        ob_start();
?>
<div class="banner banner--bannertwo">
    <div class="hostbanner overflow-hidden">
        <div class="swiper-wrapper">
            <?php foreach ( $slider_items as $item ) : ?>
            <div class="swiper-slide"
                style="background:url('<?php echo esc_url( $item['slide_image']['url'] ); ?>'); background-repeat: no-repeat; background-size: cover;">
                <div class="container">
                    <div
                        class="banner__content banner__content--contentpage2 row justify-content-center overflow-hidden">
                        <div class="col-lg-8">
                            <h3><?php echo esc_html( $item['title'] ); ?></h3>
                            <p><?php echo esc_html( $item['details'] ); ?></p>
                            <div class="bannerbtn">
                                <a href="<?php echo esc_url( $item['button_link']['url'] ); ?>" class="custom-btn">
                                    <?php echo esc_html( $item['button_text'] ); ?>
                                </a>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php endforeach; ?>

        </div>
    </div>
</div>
<?php
        return ob_get_clean();
    }
}