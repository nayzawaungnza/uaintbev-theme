<?php
namespace UaintbevCore;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Uaintbev_Core_Custom_Post_Widget extends Widget_Base {

    public function get_name() {
        return 'custom_post_widget';
    }

    public function get_title() {
        return 'UA Int Bev Custom Post Widget';
    }

    public function get_icon() {
        return 'eicon-post-list';
    }

    public function get_categories() {
        return ['uaintbev-category'];
    }

    protected function _register_controls() {

        // Section for Service Selection
        $this->start_controls_section(
            'custom_post_settings',
            [
                'label' => 'UA Int Bev Post Settings',
            ]
        );

        $this->add_control(
            'post_style',
            [
                'label' => 'Post Style',
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => 'Style 1',
                    'style_2' => 'Style 2',
                ],
                'default' => 'style_1',
            ]
        );

        $this->add_control(
            'custom_post_types',
            [
                'label' => 'Post Type',
                'type' => Controls_Manager::SELECT2,
                'options' => $this->get_custom_post_types(),
                'multiple' => false,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'post_count',
            [
                'label' => 'Number of Posts',
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
            ]
        );

        $this->end_controls_section();

        // Section for Dynamic Fields
        $this->start_controls_section(
            'post_content',
            [
                'label' => 'Posts Content',
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => 'Title',
                'type' => Controls_Manager::TEXT,
                'default' => 'Our News Update',
                'placeholder' => 'Enter your title here',
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => 'Subtitle',
                'type' => Controls_Manager::TEXT,
                'default' => 'Latest Blogs & Articles',
                'placeholder' => 'Enter your subtitle here',
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => 'Description',
                'type' => Controls_Manager::TEXTAREA,
                'default' => '',
                'placeholder' => 'Enter your description here',
            ]
        );

        $this->add_control(
            'shape_image',
            [
                'label' => 'Shape Image',
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'logo_image',
            [
                'label' => 'Logo Image',
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => 'Button Text',
                'type' => Controls_Manager::TEXT,
                'default' => 'View All Post',
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => 'Button Link',
                'type' => Controls_Manager::URL,
                'placeholder' => 'https://your-link.com',
            ]
        );

       

        $this->end_controls_section();
    }

    private function get_custom_post_types() {
        $custom_post_types = get_post_types(['public' => true], 'objects');
        $options = [];
        foreach ($custom_post_types as $type => $obj) {
            $options[$type] = $obj->label;
        }
        return $options;
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
    
        // Get settings
        $blog_style = $settings['post_style'] ?? 'style_1';
        $custom_post_types = $settings['custom_post_types'] ?? 'post';
        $post_count = $settings['post_count'] ?? 6;
    
        // Query arguments
        $args = [
            'post_type' => $custom_post_types,
            'posts_per_page' => $post_count,
        ];
    
        // Query posts
        $posts = new \WP_Query($args);
    
        // Render styles
        switch ($blog_style) {
            case 'style_1':
                echo $this->get_posts_style_1_html($settings, $posts);
                break;
            case 'style_2':
                echo $this->get_posts_style_2_html($settings, $posts);
                break;
            default:
                echo '<p>' . esc_html__('Invalid style selected.', 'text-domain') . '</p>';
                break;
        }
    }
    
    
    private function get_posts_style_1_html($settings, $posts) {
        ob_start();
        ?>

<section class="blog padding-block overflow-hidden">
    <div class="container">
        <div class="section__header blog__header">
            <div class="row align-items-center justify-content-between">
                <div class="col-md-8 col-lg-9 col-xl-9">
                    <span><?php echo esc_html($settings['title']); ?>
                        <?php if (!empty($settings['logo_image']['url'])) : ?>
                        <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                        <?php endif; ?>
                    </span>
                    <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                    <p><?php echo esc_html($settings['description']); ?></p>
                </div>
                <div class="col-md-4 col-lg-3 col-xl-2">
                    <?php if (!empty($settings['button_text'])) : ?>

                    <div class="blog__btn mt-md-0 mt-4">
                        <a href="<?php echo esc_url($settings['button_link']['url']); ?>" class="custom-btn">
                            <?php echo esc_html($settings['button_text']); ?>
                        </a>
                    </div>
                    <?php endif; ?>


                </div>
            </div>
        </div>
        <div class="section__wrapper">
            <div class="row justify-content-center g-4">
                <?php
                            if ($posts->have_posts()) :
                                
                                while ($posts->have_posts()) : $posts->the_post();
                                    $post_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                    $view_count = get_post_meta(get_the_ID(), 'post_view_count', true);
                                    $author = get_the_author();
                                    ?>

                <div class="col-md-6 col-xl-4">
                    <div class="blog__item">
                        <div class="blog__inner">
                            <div class="thumb">
                                <a href="<?php the_permalink(); ?>">
                                    <img src="<?php echo $post_image; ?>" alt="<?php the_title(); ?>">
                                </a>
                            </div>
                            <div class="content bg-white">
                                <div class="text">
                                    <h6><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
                                    <ul>
                                        <li>
                                            <a href="#">
                                                <i class="fa-solid fa-user"></i>
                                                <?php echo $author; ?>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa-regular fa-eye"></i>
                                                <?php echo esc_html(($view_count) ? $view_count : 0); ?>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa-solid fa-message"></i>
                                                <?php echo esc_html(get_comments_number(get_the_ID())); ?>
                                                Comment
                                            </a>
                                        </li>
                                    </ul>
                                    <p><?php the_excerpt(); ?></p>
                                </div>


                                <div class="blogbtn">
                                    <a href="<?php the_permalink(); ?>" class="custom-btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <?php
                        
                                endwhile;
                            else :
                                echo '<p>No post found.</p>';
                            endif;
        
                            wp_reset_postdata();
                            ?>


            </div>
        </div>
    </div>
    <div class="positionblog topshape dnone">
        <img src="assets/img/home-1/banner/shape1.png" alt="bakul">
    </div>
    <div class="bottomshape right-left d-lg-block d-none">
        <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="bakul">
    </div>
</section>

<?php
        return ob_get_clean();
    }
    
    private function get_posts_style_2_html($settings, $posts) {
        ob_start();
        ?>
<section class="blog padding-block overflow-hidden">
    <div class="container">
        <div class="section__header section__header--header2 blog__headerpage3">
            <div class="row align-items-center justify-content-between">
                <div class="col-md-12 col-lg-12 col-xl-12">
                    <span><?php echo esc_html($settings['title']); ?>
                        <?php if (!empty($settings['logo_image']['url'])) : ?>
                        <img src="<?php echo esc_url($settings['logo_image']['url']); ?>" alt="Logo">
                        <?php endif; ?>
                    </span>
                    <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                    <p><?php echo esc_html($settings['description']); ?></p>
                </div>

            </div>
        </div>
        <div class="section__wrapper">
            <div class="row justify-content-center g-4">
                <?php
                            if ($posts->have_posts()) :
                                
                                while ($posts->have_posts()) : $posts->the_post();
                                    $post_image = get_the_post_thumbnail_url(get_the_ID(), 'full');
                                    $view_count = get_post_meta(get_the_ID(), 'post_view_count', true);
                                    $author = get_the_author();
                                    ?>

                <div class="col-md-6 col-xl-4">
                    <div class="blog__item">
                        <div class="blog__inner">
                            <div class="thumb">
                                <a href="<?php the_permalink(); ?>">
                                    <img src="<?php echo $post_image; ?>" alt="<?php the_title(); ?>">
                                </a>
                            </div>
                            <div class="content bg-white">
                                <div class="text">
                                    <ul>
                                        <li>
                                            <a href="#">
                                                <i class="fa-solid fa-user"></i>
                                                <?php echo $author; ?>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa-regular fa-eye"></i>
                                                <?php echo ($view_count) ? $view_count : 0; ?>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <i class="fa-solid fa-message"></i>
                                                <?php echo get_comments_number(get_the_ID()); ?>
                                                Comment
                                            </a>
                                        </li>
                                    </ul>
                                    <h6><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h6>
                                </div>
                                <div class="blogbtn">
                                    <a href="<?php the_permalink(); ?>" class="custom-btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <?php
                        
                                endwhile;
                            else :
                                echo '<p>No post found.</p>';
                            endif;
        
                            wp_reset_postdata();
                            ?>


            </div>
        </div>
    </div>
    <div class="positionblog topshape dnone">
        <img src="assets/img/home-1/banner/shape1.png" alt="bakul">
    </div>
    <div class="bottomshape right-left d-lg-block d-none">
        <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="bakul">
    </div>
</section>
<?php
        return ob_get_clean();
    }

    
}     