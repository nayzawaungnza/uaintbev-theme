<?php

namespace UaintbevCore;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

class Uaintbev_Core_Company_Achivement_Widget extends Widget_Base {

    public function get_name() {
        return 'company_achivement';
    }

    public function get_title() {
        return __('Uaintbev Company Achivement', 'uaintbev-core');
    }

    public function get_icon() {
        return 'eicon-upgrade-crown';
    }

    public function get_categories() {
        return ['uaintbev-category'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'uaintbev-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __('Title', 'uaintbev-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'placeholder' => __('Enter your title here', 'uaintbev-core'),
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => __('Subtitle', 'uaintbev-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '',
                'placeholder' => __('Enter your subtitle here', 'uaintbev-core'),
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => __('Description', 'uaintbev-core'),
                'type' => Controls_Manager::WYSIWYG,
                'default' => '',
                'placeholder' => __('Enter your description here', 'uaintbev-core'),
            ]
        );

        $this->add_control(
            'background_image',
            [
                'label' => __('Background Image', 'uaintbev-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'logo_image',
            [
                'label' => __('Logo Image', 'uaintbev-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->end_controls_section();

        // Achievement Section
        $this->start_controls_section(
            'achivement_item_section',
            [
                'label' => __('Achivement', 'uaintbev-core'),
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'icon',
            [
                'label' => __('Icon', 'uaintbev-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label' => __('Title', 'uaintbev-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $repeater->add_control(
            'odometer',
            [
                'label' => __('Odometer', 'uaintbev-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 0,
            ]
        );

        $repeater->add_control(
            'description',
            [
                'label' => __('Description', 'uaintbev-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Continually productize compelling quality for packed in business consulting.', 'uaintbev-core'),
            ]
        );

        $this->add_control(
            'achivement_item',
            [
                'label' => __('Achivement Items', 'uaintbev-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $title = $settings['title'] ?? '';
        $subtitle = $settings['subtitle'] ?? '';
        $description = $settings['description'] ?? '';
        $background = $settings['background_image']['url'] ?? '';
        $logo_image = $settings['logo_image']['url'] ?? '';

        ?>
<div class="counter overflow-hidden padding-block overly"
    style="background-image: url(<?php echo esc_url($background); ?>);">
    <div class="container">
        <div class="row g-5 justify-content-center">
            <?php if (!empty($settings['achivement_item'])) : ?>
            <?php foreach ($settings['achivement_item'] as $item) : ?>
            <div class="col-6 col-md-4 col-lg-3">
                <div class="counter__item">
                    <div class="counter__inner go-up">
                        <div class="thumb">
                            <img src="<?php echo esc_url($item['icon']['url']); ?>"
                                alt="<?php echo esc_attr($item['title']); ?>">
                        </div>
                        <div class="counter__content">
                            <div class="maincounter">
                                <h4 class="odometer" data-odometer-final="<?php echo esc_html($item['odometer']); ?>">
                                    <?php echo esc_html($item['odometer']); ?></h4>
                            </div>
                            <h6><?php echo esc_html($item['title']); ?></h6>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
    }
}