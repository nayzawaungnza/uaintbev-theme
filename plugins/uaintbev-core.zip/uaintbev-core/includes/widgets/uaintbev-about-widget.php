<?php

namespace UaintbevCore;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Uaintbev_Core_Welcome_Widget extends Widget_Base {

    public function get_name() {
        return 'uaintbev_welcome_content';
    }

    public function get_title() {
        return __( 'Uaintbev Welcome Content', 'uaintbev-core' );
    }

    public function get_icon() {
        return 'eicon-welcome';
    }

    public function get_categories() {
        return [ 'uaintbev-category' ];
    }

    protected function register_controls() {

        // Section: Settings
        $this->start_controls_section(
            'section_service_settings',
            [
                'label' => __( 'Uaintbev Welcome Settings', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'uaintbev_style',
            [
                'label'   => __( 'Uaintbev Welcome Style', 'uaintbev-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    'style_1' => __( 'Style 1', 'uaintbev-core' ),
                    'style_2' => __( 'Style 2', 'uaintbev-core' ),
                    'style_3' => __( 'Style 3', 'uaintbev-core' ),
                ],
                'default' => 'style_3',
            ]
        );

        $this->add_image_controls([
            'main_image'    => __( 'Main Image', 'uaintbev-core' ),
            'garden_icon'   => __( 'Garden Icon Image', 'uaintbev-core' ),
            'award_icon'    => __( 'Award Icon Image', 'uaintbev-core' ),
            'shape_image'   => __( 'Shape Image', 'uaintbev-core' ),
            'topleftimg'  => __( 'Top Left Image', 'uaintbev-core' ),
            'bottomleftimg' => __( 'Bottom Left Image', 'uaintbev-core' ),
        ]);

        $this->end_controls_section();

        // Section: Content
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Uaintbev Welcome Content', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'title',
            [
                'label'   => __( 'Title', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Natureplant Services', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label'   => __( 'Subtitle', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Nature plant Best Services For Your Gardening.', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'description',
            [
                'label'   => __( 'Description', 'uaintbev-core' ),
                'type'    => Controls_Manager::WYSIWYG,
                'default' => __( 'Continually productize compelling quality for packed in business consulting.', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label'   => __( 'Button Text', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => __( 'Read More', 'uaintbev-core' ),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label'       => __( 'Button Link', 'uaintbev-core' ),
                'type'        => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'uaintbev-core' ),
            ]
        );

        // Award Section
        $this->add_control(
            'garden_odometer',
            [
                'label'   => __( 'Garden Odometer', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $this->add_control(
            'garden_title',
            [
                'label'   => __( 'Garden Title', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $this->add_control(
            'award_odometer',
            [
                'label'   => __( 'Award Odometer', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $this->add_control(
            'award_title',
            [
                'label'   => __( 'Award Title', 'uaintbev-core' ),
                'type'    => Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $this->add_control(
            'logo_image',
            [
                'label' => __( 'Logo Image', 'uaintbev-core' ),
                'type'  => Controls_Manager::MEDIA,
            ]
        );

        $this->end_controls_section();
    }

    private function add_image_controls( $images ) {
        foreach ( $images as $name => $label ) {
            $this->add_control(
                $name,
                [
                    'label'   => $label,
                    'type'    => Controls_Manager::MEDIA,
                    //'default' => [ 'url' => Utils::get_placeholder_image_src() ],
                ]
            );
        }
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        $uaintbev_style = $settings['uaintbev_style'] ?? 'style_1';

        switch ( $uaintbev_style ) {
            case 'style_2':
                echo $this->render_uaintbev_style_2( $settings );
                break;
            case 'style_3':
                echo $this->render_uaintbev_style_3( $settings );
                break;
            default:
                echo $this->render_uaintbev_style_1( $settings );
        }
    }
    private function transform_content($content) {
        // Initialize a new DOMDocument
        $doc = new \DOMDocument();
    
        // Suppress warnings for malformed HTML and load the content
        @$doc->loadHTML('<?xml encoding="utf-8" ?>' . $content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

// Find all `<ul>` elements in the content
    $ulElements = $doc->getElementsByTagName('ul');

    // Iterate through each `<ul>` element
        foreach ($ulElements as $ul) {
        // Process each `<li>` within the `<ul>`
                foreach ($ul->getElementsByTagName('li') as $li) {
                // Create a new <i> element with the desired Font Awesome classes
                    $icon = $doc->createElement('i');
                    $icon->setAttribute('class', 'fa-sharp fa-solid fa-square-check');

                    // Insert the <i> element at the beginning of the <li> element
                            $li->insertBefore($icon, $li->firstChild);
                            }
                            }

                            // Save and return the transformed HTML content
                            return $doc->saveHTML($doc->documentElement);
                            }

                            private function render_uaintbev_style_1( $settings ) {
                            ob_start();
                            ?>
                            <section class="natureplant overflow-hidden">
                                <div class="container">
                                    <div class="row justify-content-xxl-center justify-content-center">
                                        <div class="col-lg-10 col-xl-8 col-xxl-8">
                                            <div class="section__header natureplant__header text-center">
                                                <div class="col-md-12 col-xl-12 col-xxl-12">
                                                    <span> <?php echo esc_html( $settings['title'] ); ?><img
                                                            src="<?php echo esc_url( $settings['logo_image']['url'] ); ?>"
                                                            alt="bakul"></span>
                                                    <h3><?php echo esc_html( $settings['subtitle'] ); ?></h3>
                                                </div>
                                            </div>
                                            <div class="section__wrapper natureplant__content uaintbev_content text-center">
                                                <?php echo wp_kses_post($settings['description']); ?>
                                                <div class="natureplant__gardingmake">
                                                    <?php if ( ! empty( $settings['garden_odometer'] ) ) : ?>
                                                    <div class="item">
                                                        <div class="thumb">
                                                            <img src="<?php echo esc_url( $settings['garden_icon']['url'] ); ?>"
                                                                alt="bakul">
                                                        </div>
                                                        <div class="text">
                                                            <h5 class="odometer"
                                                                data-odometer-final="<?php echo esc_html( $settings['garden_odometer'] ); ?>">
                                                                <?php echo esc_html( $settings['garden_odometer'] ); ?>
                                                            </h5>
                                                            <h6><?php echo esc_html( $settings['garden_title'] ); ?>
                                                            </h6>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php if ( ! empty( $settings['award_odometer'] ) ) : ?>
                                                    <div class="item">
                                                        <div class="thumb">
                                                            <img src="<?php echo esc_url( $settings['award_icon']['url'] ); ?>"
                                                                alt="bakul">
                                                        </div>
                                                        <div class="text">
                                                            <h5 class="odometer"
                                                                data-odometer-final="<?php echo esc_html( $settings['award_odometer'] ); ?>">
                                                                <?php echo esc_html( $settings['award_odometer'] ); ?>
                                                            </h5>
                                                            <h6><?php echo esc_html( $settings['award_title'] ); ?></h6>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                                <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>"
                                                    class="custom-btn"><?php echo esc_html( $settings['button_text'] ); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								 <?php if ( ! empty( $settings['topleftimg']['url'] ) ) : ?>
                                <div class="position leftimg imghover d-xxl-block d-none">
                                    <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
                                </div>
								<?php endif; ?>
                                <?php if ( ! empty( $settings['bottomleftimg']['url'] ) ) : ?>
                                <div class="rightshape right-left d-lg-block d-none">
                                    <img src="<?php echo esc_url($settings['bottomleftimg']['url']); ?>" alt="bakul">
                                </div>
                                <?php endif; ?>
								 <?php if ( ! empty( $settings['topleftimg']['url'] ) ) : ?>
                                <div class="position topshape d-xxl-block d-none">
                                    <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
                                </div>
								 <?php endif; ?>
<!--                                 <div class="position middleshape d-xxl-block d-none">
                                    <img src="assets/img/home-1/welcome/middleshape.png" alt="bakul">
                                </div> -->
                            </section>
                            <?php
        return ob_get_clean();
    }

    private function render_uaintbev_style_2( $settings ) {
        ob_start();
        ?>
                            <section class="natureplant natureplant--natureplantpage2 bg-white">
                                <div class="container">
                                    <div class="row align-items-center g-4 justify-content-center">
                                        <div class="col-xl-5">
                                            <div class="section__header">
                                                <div class="col-md-12">
                                                    <span><?php echo esc_html($settings['title']); ?><img
                                                            src="<?php echo esc_url($settings['logo_image']['url']); ?>"
                                                            alt="bakul"></span>
                                                    <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                                                </div>
                                            </div>
                                            <div
                                                class="section__wrapper natureplant__content natureplant__content--contentpage2">
                                                <?php echo wp_kses_post($settings['description']); ?>
                                                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                                                    class="custom-btn"><?php echo esc_html($settings['button_text']); ?></a>
                                            </div>
                                        </div>
                                        <div class="col-xl-7">
                                            <div class="natureplant__innerimg imghover">
                                                <img src="<?php echo esc_url($settings['main_image']['url']); ?>"
                                                    alt="bakul">
                                                <?php if ( ! empty( $settings['garden_odometer'] ) ) : ?>
                                                <div class="counteritem">
                                                    <div class="thumb">
                                                        <img src="<?php echo esc_url($settings['garden_icon']['url']); ?>"
                                                            alt="bakul">
                                                    </div>
                                                    <div class="text">
                                                        <h5 class="odometer"
                                                            data-odometer-final="<?php echo esc_html( $settings['garden_odometer'] ); ?>">
                                                            <?php echo esc_html( $settings['garden_odometer'] ); ?></h5>
                                                        <h6><?php echo esc_html($settings['garden_title']); ?></h6>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php if ( ! empty( $settings['award_odometer'] ) ) : ?>
                                                <div class="counteritem counteritem2">
                                                    <div class="thumb">
                                                        <img src="<?php echo esc_url($settings['award_icon']['url']); ?>"
                                                            alt="bakul">
                                                    </div>
                                                    <div class="text">
                                                        <h5 class="odometer"
                                                            data-odometer-final="<?php echo esc_html( $settings['award_odometer'] ); ?>">
                                                            <?php echo esc_html( $settings['award_odometer'] ); ?></h5>
                                                        <h6><?php echo esc_html($settings['award_title']); ?></h6>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if ( ! empty( $settings['topleftimg']['url'] ) ) : ?>
                                <div class="topleftimg left-right dnone">
                                    <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
                                </div>
                                <?php endif; ?>
                                <?php if ( ! empty( $settings['bottomleftimg']['url'] ) ) : ?>
                                <div class="bottomright right-left d-lg-block d-none">
                                    <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="bakul">
                                </div>
                                <?php endif; ?>
                            </section>
                            <?php
        return ob_get_clean();
    }

    private function render_uaintbev_style_3( $settings ) {
        ob_start();
        ?>
                            <section
                                class="natureplant natureplant--natureplantpage3 natureplant--natureplantpage2 bg-white">
                                <div class="container">
                                    <div class="row g-4 align-items-xxl-center align-items-end justify-content-center">
                                        <div class="col-xl-5 col-xxl-7 text-center imghover">
                                            <img src="<?php echo esc_url($settings['main_image']['url']); ?>"
                                                alt="bakul">
                                        </div>
                                        <div class="col-lg-10 col-xl-7 col-xxl-5">
                                            <div class="section__header">
                                                <div class="col-xl-8">
                                                    <span><?php echo esc_html($settings['title']); ?><img
                                                            src="<?php echo esc_url($settings['logo_image']['url']); ?>"
                                                            alt="bakul"></span>
                                                    <h3><?php echo esc_html($settings['subtitle']); ?></h3>
                                                </div>
                                            </div>
                                            <div class="section__wrapper natureplant__content">
                                                <?php echo wp_kses_post($settings['description']); ?>
                                                <div class="natureplant__gardingmake">
                                                    <?php if ( ! empty( $settings['garden_odometer'] ) ) : ?>
                                                    <div class="item">
                                                        <div class="thumb">
                                                            <img src="<?php echo esc_url($settings['garden_icon']['url']); ?>"
                                                                alt="bakul">
                                                        </div>

                                                        <div class="text">
                                                            <h5 class="odometer"
                                                                data-odometer-final="<?php echo esc_html($settings['garden_odometer']); ?>">
                                                                <?php echo esc_html($settings['garden_odometer']); ?>
                                                            </h5>
                                                            <h6><?php echo esc_html($settings['garden_title']); ?></h6>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php if ( ! empty( $settings['award_odometer'] ) ) : ?>
                                                    <div class="item">
                                                        <div class="thumb">
                                                            <img src="<?php echo esc_url($settings['award_icon']['url']); ?>"
                                                                alt="bakul">
                                                        </div>
                                                        <div class="text">
                                                            <h5 class="odometer"
                                                                data-odometer-final="<?php echo esc_html($settings['award_odometer']); ?>">
                                                                <?php echo esc_html($settings['award_odometer']); ?>
                                                            </h5>
                                                            <h6><?php echo esc_html($settings['award_title']); ?></h6>
                                                        </div>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                                <?php if ( ! empty( $settings['button_text'] ) ) : ?>
                                                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"
                                                    class="custom-btn"><?php echo esc_html($settings['button_text']); ?></a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if ( ! empty( $settings['bottomleftimg']['url'] ) ) : ?>
                                <div class="samepositon bottomright d-md-block d-none">
                                    <img src="<?php echo esc_url($settings['bottomleftimg']['url']); ?>" alt="bakul">
                                </div>
                                <?php endif; ?>
                                <?php if ( ! empty( $settings['topleftimg']['url'] ) ) : ?>
                                <div class="samepositon topright d-xl-block d-none">
                                    <img src="<?php echo esc_url($settings['topleftimg']['url']); ?>" alt="bakul">
                                </div>
                                <?php endif; ?>
                                <?php if ( ! empty( $settings['shape_image']['url'] ) ) : ?>
                                <div class="topleftimg top-bottom d-xl-block d-none">
                                    <img src="<?php echo esc_url($settings['shape_image']['url']); ?>" alt="bakul">
                                </div>
                                <?php endif; ?>
                            </section>
                            <?php
        return ob_get_clean();
    }
}