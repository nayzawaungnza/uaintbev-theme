<?php
/**
*Plugin Name: UA Int Bev Core
*Plugin URI: https://www.uaintbev.com
*Description: The uaintbev-core plugin is designed to enhance the functionality of the uaintbev theme. It provides essential features and customizations, including custom post types, taxonomies, widgets, and shortcodes, tailored specifically for tobacco farming and retail businesses. This plugin ensures seamless integration with the uaintbev theme, enabling a fully functional website.
*Version: 1.0.0
*Author: Nay Zaw Aung
*Author URI: https://nay-react.vercel.app
*License: GPL2
*Text Domain: uaintbev-core
*Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Register UA Int Bev category
function uaintbev_core_register_category( $elements_manager ) {
    $elements_manager->add_category(
        'uaintbev-category',
        [
            'title' => __( 'UA Int Bev', 'uaintbev-core' ),
            'icon' => 'fa fa-plug',
            'position' => 1,
        ]
    );
}
add_action( 'elementor/elements/categories_registered', 'uaintbev_core_register_category' );


// Load custom widgets
function uaintbev_core_load_widgets() {
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-slider-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-about-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/contact-details-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/contact-request-form-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-services-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-company-achivement.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-feature-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-project-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-faqs-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-blog-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-custom-post-widget.php';
    require_once plugin_dir_path( __FILE__ ) . 'includes/widgets/uaintbev-text-widget.php';
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Slider_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Welcome_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Company_Achivement_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Feature_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Project_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Faqs_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Blog_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Custom_Post_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Text_Widget() );
    
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Uaintbev_Core_Contact_Details_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Contact_Request_Form_Widget() );
    \Elementor\Plugin::instance()->widgets_manager->register( new \UaintbevCore\Service_Widget() );
    
}
add_action( 'elementor/widgets/register', 'uaintbev_core_load_widgets' );


// Enqueue scripts and styles
// function uaintbev_core_enqueue_styles() {
//     wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css' );
// }
// add_action( 'wp_enqueue_scripts', 'uaintbev_core_enqueue_styles' );